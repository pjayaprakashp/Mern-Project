export const DEAL_DATA="Deal Data";
export const GET_DATA_SUCCESS="get Data success" 
export const GET_DATA_REQUEST="get Data Request" 
export const GET_DATA_ERROR="get Data Error" 

