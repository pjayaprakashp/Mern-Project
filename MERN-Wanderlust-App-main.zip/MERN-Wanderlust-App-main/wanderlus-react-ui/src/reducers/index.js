import reducer from './reducers.js'
import {combineReducers} from "reducer"

export default combineReducers({
    reducer
});

